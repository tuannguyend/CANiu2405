#ifndef TRACEMANAGER_H
#define TRACEMANAGER_H

#include <QMainWindow>
#include <utilities.h>
#include "simulatormvcommon.h"
#include "measuresetup.h"
#include "ui_tracemanager.h"

typedef enum{
    E_IndexColumn_Time=0,
    E_IndexColumn_Channel,
    E_IndexColumn_ID,
    E_IndexColumn_Name,
    E_IndexColumn_EventType,
    E_IndexColumn_Direction,
    E_IndexColumn_DLC,
    E_IndexColumn_Data,
}E_IndexColumn;

class TraceManager;
class TraceDataModel: public MeasureSetupCommonModel
{
    Q_OBJECT
public:
    //  0          1           2        3       4                5        6         7
    //"Time" << "Channel" << "ID" << "Name" << "Event Type" << "Dir" << "DLC" << "Data"
    explicit TraceDataModel(QObject *parent = 0);
    ~TraceDataModel(){}
    QVariant data(const QModelIndex &index, int role) const override;
    QVariant headerData(int section, Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const override;
    bool setData(const QModelIndex &index, const QVariant &value,
                 int role = Qt::EditRole) override;
    bool setHeaderData(int section, Qt::Orientation orientation,
                       const QVariant &value, int role = Qt::EditRole) override;
    Qt::ItemFlags flags(const QModelIndex &index) const override;

    void setTimeDisplay(bool delta){
        m_DeltaT = delta;
        emit dataChanged(QModelIndex(),QModelIndex());
    }
    void setPlayPause(bool play){
        m_Play = play;
        emit dataChanged(QModelIndex(),QModelIndex());
    }
    void reset();
private:
    bool m_DeltaT;
    bool m_Play;
};

class TraceWindow : public QMainWindow,Ui_TraceManager
{
    Q_OBJECT

public:
    explicit TraceWindow(QWidget *parent = 0, TraceManager * manager = 0);
    ~TraceWindow();

private:
    TraceManager *m_TraceManager;
};

class TraceManager: public MeasureSetupManagerCommon{
    Q_OBJECT
public:
    TraceManager(QObject * parent = 0,CANSimulatorDatabaseAssosiate * DbAssosiate=0){
        m_DbAssosiate=DbAssosiate;
        m_TraceModel = new TraceDataModel(parent);
        m_DeltaT = false;
        m_Play = true;
    }
    TraceDataModel * getModel(){return m_TraceModel;}
    bool process(MeasureSetupMessageCommon * message);
public slots:
    void toggleTimeDisplay(){
        m_DeltaT = !m_DeltaT;
        if(m_TraceModel){
            m_TraceModel->setTimeDisplay(m_DeltaT);
        }
    }
    void togglePlayPause(){
        m_Play = ! m_Play;
        if(m_TraceModel){
            m_TraceModel->setPlayPause(m_Play);
        }
    }

private:
    bool m_DeltaT;
    bool m_Play;
    int getMatchRow(CANMessageSimulate CANMsg);
    CANSimulatorDatabaseAssosiate * m_DbAssosiate;
    TraceDataModel * m_TraceModel;
};


#endif // TRACEMANAGER_H

/********************************************************************************
** Form generated from reading UI file 'filtermanager.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FILTERMANAGER_H
#define UI_FILTERMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FilterManager
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *m_OkButton;
    QPushButton *m_CancelButton;
    QHBoxLayout *horizontalLayout_2;
    QCheckBox *m_StopFilterCheck;
    QPushButton *m_InsertMessageButton;
    QPushButton *m_InsertRangeButton;
    QPushButton *m_RemoveButton;
    QSpacerItem *horizontalSpacer_2;
    QTableWidget *m_TableFilter;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *FilterManager)
    {
        if (FilterManager->objectName().isEmpty())
            FilterManager->setObjectName(QStringLiteral("FilterManager"));
        FilterManager->resize(1020, 628);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(FilterManager->sizePolicy().hasHeightForWidth());
        FilterManager->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        FilterManager->setWindowIcon(icon);
        centralwidget = new QWidget(FilterManager);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        m_OkButton = new QPushButton(centralwidget);
        m_OkButton->setObjectName(QStringLiteral("m_OkButton"));

        horizontalLayout->addWidget(m_OkButton);

        m_CancelButton = new QPushButton(centralwidget);
        m_CancelButton->setObjectName(QStringLiteral("m_CancelButton"));

        horizontalLayout->addWidget(m_CancelButton);


        gridLayout->addLayout(horizontalLayout, 5, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        m_StopFilterCheck = new QCheckBox(centralwidget);
        m_StopFilterCheck->setObjectName(QStringLiteral("m_StopFilterCheck"));
        QFont font;
        font.setBold(false);
        font.setWeight(50);
        m_StopFilterCheck->setFont(font);

        horizontalLayout_2->addWidget(m_StopFilterCheck);

        m_InsertMessageButton = new QPushButton(centralwidget);
        m_InsertMessageButton->setObjectName(QStringLiteral("m_InsertMessageButton"));
        QFont font1;
        font1.setBold(false);
        font1.setWeight(50);
        font1.setStrikeOut(false);
        font1.setKerning(true);
        m_InsertMessageButton->setFont(font1);

        horizontalLayout_2->addWidget(m_InsertMessageButton);

        m_InsertRangeButton = new QPushButton(centralwidget);
        m_InsertRangeButton->setObjectName(QStringLiteral("m_InsertRangeButton"));
        m_InsertRangeButton->setFont(font);

        horizontalLayout_2->addWidget(m_InsertRangeButton);

        m_RemoveButton = new QPushButton(centralwidget);
        m_RemoveButton->setObjectName(QStringLiteral("m_RemoveButton"));
        QFont font2;
        font2.setBold(false);
        font2.setItalic(false);
        font2.setWeight(50);
        m_RemoveButton->setFont(font2);

        horizontalLayout_2->addWidget(m_RemoveButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        gridLayout->addLayout(horizontalLayout_2, 1, 0, 1, 1);

        m_TableFilter = new QTableWidget(centralwidget);
        if (m_TableFilter->columnCount() < 10)
            m_TableFilter->setColumnCount(10);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(7, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(8, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        m_TableFilter->setHorizontalHeaderItem(9, __qtablewidgetitem9);
        m_TableFilter->setObjectName(QStringLiteral("m_TableFilter"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_TableFilter->sizePolicy().hasHeightForWidth());
        m_TableFilter->setSizePolicy(sizePolicy1);
        m_TableFilter->setLineWidth(2);
        m_TableFilter->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        m_TableFilter->setHorizontalScrollMode(QAbstractItemView::ScrollPerPixel);
        m_TableFilter->horizontalHeader()->setDefaultSectionSize(100);
        m_TableFilter->horizontalHeader()->setMinimumSectionSize(10);
        m_TableFilter->verticalHeader()->setVisible(true);
        m_TableFilter->verticalHeader()->setDefaultSectionSize(18);
        m_TableFilter->verticalHeader()->setMinimumSectionSize(10);

        gridLayout->addWidget(m_TableFilter, 0, 0, 1, 1);

        FilterManager->setCentralWidget(centralwidget);
        menubar = new QMenuBar(FilterManager);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1020, 21));
        FilterManager->setMenuBar(menubar);
        statusbar = new QStatusBar(FilterManager);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        FilterManager->setStatusBar(statusbar);

        retranslateUi(FilterManager);

        QMetaObject::connectSlotsByName(FilterManager);
    } // setupUi

    void retranslateUi(QMainWindow *FilterManager)
    {
        FilterManager->setWindowTitle(QApplication::translate("FilterManager", "Filter Setup", Q_NULLPTR));
        m_OkButton->setText(QApplication::translate("FilterManager", "OK", Q_NULLPTR));
        m_CancelButton->setText(QApplication::translate("FilterManager", "Cancel", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        m_StopFilterCheck->setToolTip(QApplication::translate("FilterManager", "<html><head/><body><p>Checked: stop filter</p><p>Unchecked: pass filter</p></body></html>", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        m_StopFilterCheck->setText(QApplication::translate("FilterManager", "StopFilter", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        m_InsertMessageButton->setToolTip(QApplication::translate("FilterManager", "Insert message from assosiate database", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        m_InsertMessageButton->setText(QApplication::translate("FilterManager", "Insert CAN Message", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        m_InsertRangeButton->setToolTip(QApplication::translate("FilterManager", "Insert Identifier range", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        m_InsertRangeButton->setText(QApplication::translate("FilterManager", "Insert Range", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        m_RemoveButton->setToolTip(QApplication::translate("FilterManager", "Remove a row", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        m_RemoveButton->setText(QApplication::translate("FilterManager", "Remove", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = m_TableFilter->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("FilterManager", "Database Name", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = m_TableFilter->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("FilterManager", "Name", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = m_TableFilter->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("FilterManager", "Identifier", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = m_TableFilter->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("FilterManager", "Type", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = m_TableFilter->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("FilterManager", "Channel", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = m_TableFilter->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("FilterManager", "Rx", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = m_TableFilter->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QApplication::translate("FilterManager", "Tx", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = m_TableFilter->horizontalHeaderItem(7);
        ___qtablewidgetitem7->setText(QApplication::translate("FilterManager", "TxReq", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = m_TableFilter->horizontalHeaderItem(8);
        ___qtablewidgetitem8->setText(QApplication::translate("FilterManager", "RTR Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = m_TableFilter->horizontalHeaderItem(9);
        ___qtablewidgetitem9->setText(QApplication::translate("FilterManager", "RTR Remote", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class FilterManager: public Ui_FilterManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FILTERMANAGER_H

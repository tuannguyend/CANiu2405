/********************************************************************************
** Form generated from reading UI file 'interactivemanager.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INTERACTIVEMANAGER_H
#define UI_INTERACTIVEMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_InteractiveManager
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QTableWidget *m_TableWidgetMsg;
    QTableWidget *m_TableWidgetSgn;
    QHBoxLayout *horizontalLayout;
    QPushButton *m_AddNewButton;
    QPushButton *m_DeleteButton;
    QPushButton *m_SpecialFrameButton;
    QSpacerItem *horizontalSpacer;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *InteractiveManager)
    {
        if (InteractiveManager->objectName().isEmpty())
            InteractiveManager->setObjectName(QStringLiteral("InteractiveManager"));
        InteractiveManager->resize(1174, 630);
        centralwidget = new QWidget(InteractiveManager);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        m_TableWidgetMsg = new QTableWidget(centralwidget);
        if (m_TableWidgetMsg->columnCount() < 15)
            m_TableWidgetMsg->setColumnCount(15);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(7, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(8, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(9, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(10, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(11, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(12, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(13, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        m_TableWidgetMsg->setHorizontalHeaderItem(14, __qtablewidgetitem14);
        m_TableWidgetMsg->setObjectName(QStringLiteral("m_TableWidgetMsg"));

        gridLayout->addWidget(m_TableWidgetMsg, 0, 0, 1, 1);

        m_TableWidgetSgn = new QTableWidget(centralwidget);
        m_TableWidgetSgn->setObjectName(QStringLiteral("m_TableWidgetSgn"));

        gridLayout->addWidget(m_TableWidgetSgn, 3, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        m_AddNewButton = new QPushButton(centralwidget);
        m_AddNewButton->setObjectName(QStringLiteral("m_AddNewButton"));

        horizontalLayout->addWidget(m_AddNewButton);

        m_DeleteButton = new QPushButton(centralwidget);
        m_DeleteButton->setObjectName(QStringLiteral("m_DeleteButton"));

        horizontalLayout->addWidget(m_DeleteButton);

        m_SpecialFrameButton = new QPushButton(centralwidget);
        m_SpecialFrameButton->setObjectName(QStringLiteral("m_SpecialFrameButton"));

        horizontalLayout->addWidget(m_SpecialFrameButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        gridLayout->addLayout(horizontalLayout, 1, 0, 1, 1);

        InteractiveManager->setCentralWidget(centralwidget);
        menubar = new QMenuBar(InteractiveManager);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1174, 21));
        InteractiveManager->setMenuBar(menubar);
        statusbar = new QStatusBar(InteractiveManager);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        InteractiveManager->setStatusBar(statusbar);

        retranslateUi(InteractiveManager);

        QMetaObject::connectSlotsByName(InteractiveManager);
    } // setupUi

    void retranslateUi(QMainWindow *InteractiveManager)
    {
        InteractiveManager->setWindowTitle(QApplication::translate("InteractiveManager", "Interactive Generator", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = m_TableWidgetMsg->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("InteractiveManager", "Message Name", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = m_TableWidgetMsg->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("InteractiveManager", "Channel", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = m_TableWidgetMsg->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("InteractiveManager", "DLC", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = m_TableWidgetMsg->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("InteractiveManager", "Trigger", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = m_TableWidgetMsg->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("InteractiveManager", "Cycle", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = m_TableWidgetMsg->horizontalHeaderItem(7);
        ___qtablewidgetitem5->setText(QApplication::translate("InteractiveManager", "Data [0-7]", Q_NULLPTR));
        m_AddNewButton->setText(QApplication::translate("InteractiveManager", "New", Q_NULLPTR));
        m_DeleteButton->setText(QApplication::translate("InteractiveManager", "Delete", Q_NULLPTR));
        m_SpecialFrameButton->setText(QApplication::translate("InteractiveManager", "Special Frame", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class InteractiveManager: public Ui_InteractiveManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INTERACTIVEMANAGER_H

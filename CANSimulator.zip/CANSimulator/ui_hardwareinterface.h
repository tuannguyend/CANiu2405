/********************************************************************************
** Form generated from reading UI file 'hardwareinterface.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HARDWAREINTERFACE_H
#define UI_HARDWAREINTERFACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_hardwareinterface
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QCheckBox *m_CAN2Used;
    QLabel *label;
    QLabel *label_2;
    QDialogButtonBox *m_ButtonBox;
    QCheckBox *m_CAN1Used;
    QPushButton *m_CheckConnection;
    QComboBox *m_CAN2Baud;
    QComboBox *m_CAN1Baud;
    QProgressBar *m_CheckProgress;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *hardwareinterface)
    {
        if (hardwareinterface->objectName().isEmpty())
            hardwareinterface->setObjectName(QStringLiteral("hardwareinterface"));
        hardwareinterface->resize(348, 134);
        centralwidget = new QWidget(hardwareinterface);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        m_CAN2Used = new QCheckBox(centralwidget);
        m_CAN2Used->setObjectName(QStringLiteral("m_CAN2Used"));
        m_CAN2Used->setChecked(true);

        gridLayout->addWidget(m_CAN2Used, 1, 1, 1, 1);

        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        m_ButtonBox = new QDialogButtonBox(centralwidget);
        m_ButtonBox->setObjectName(QStringLiteral("m_ButtonBox"));
        m_ButtonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(m_ButtonBox, 2, 3, 1, 1);

        m_CAN1Used = new QCheckBox(centralwidget);
        m_CAN1Used->setObjectName(QStringLiteral("m_CAN1Used"));
        m_CAN1Used->setChecked(true);
        m_CAN1Used->setTristate(false);

        gridLayout->addWidget(m_CAN1Used, 0, 1, 1, 1);

        m_CheckConnection = new QPushButton(centralwidget);
        m_CheckConnection->setObjectName(QStringLiteral("m_CheckConnection"));

        gridLayout->addWidget(m_CheckConnection, 2, 2, 1, 1);

        m_CAN2Baud = new QComboBox(centralwidget);
        m_CAN2Baud->setObjectName(QStringLiteral("m_CAN2Baud"));

        gridLayout->addWidget(m_CAN2Baud, 1, 2, 1, 2);

        m_CAN1Baud = new QComboBox(centralwidget);
        m_CAN1Baud->setObjectName(QStringLiteral("m_CAN1Baud"));

        gridLayout->addWidget(m_CAN1Baud, 0, 2, 1, 2);

        m_CheckProgress = new QProgressBar(centralwidget);
        m_CheckProgress->setObjectName(QStringLiteral("m_CheckProgress"));
        m_CheckProgress->setEnabled(true);
        m_CheckProgress->setValue(0);
        m_CheckProgress->setTextVisible(false);
        m_CheckProgress->setInvertedAppearance(false);

        gridLayout->addWidget(m_CheckProgress, 2, 0, 1, 2);

        hardwareinterface->setCentralWidget(centralwidget);
        menubar = new QMenuBar(hardwareinterface);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 348, 21));
        hardwareinterface->setMenuBar(menubar);
        statusbar = new QStatusBar(hardwareinterface);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        hardwareinterface->setStatusBar(statusbar);

        retranslateUi(hardwareinterface);

        QMetaObject::connectSlotsByName(hardwareinterface);
    } // setupUi

    void retranslateUi(QMainWindow *hardwareinterface)
    {
        hardwareinterface->setWindowTitle(QApplication::translate("hardwareinterface", "MainWindow", Q_NULLPTR));
        m_CAN2Used->setText(QString());
        label->setText(QApplication::translate("hardwareinterface", "CAN1:", Q_NULLPTR));
        label_2->setText(QApplication::translate("hardwareinterface", "CAN2:", Q_NULLPTR));
        m_CAN1Used->setText(QString());
        m_CheckConnection->setText(QApplication::translate("hardwareinterface", "Check", Q_NULLPTR));
        m_CAN2Baud->clear();
        m_CAN2Baud->insertItems(0, QStringList()
         << QApplication::translate("hardwareinterface", "125Kb", Q_NULLPTR)
         << QApplication::translate("hardwareinterface", "250Kb", Q_NULLPTR)
         << QApplication::translate("hardwareinterface", "500Kb", Q_NULLPTR)
         << QApplication::translate("hardwareinterface", "1000Kb", Q_NULLPTR)
        );
        m_CAN1Baud->clear();
        m_CAN1Baud->insertItems(0, QStringList()
         << QApplication::translate("hardwareinterface", "125Kb", Q_NULLPTR)
         << QApplication::translate("hardwareinterface", "250Kb", Q_NULLPTR)
         << QApplication::translate("hardwareinterface", "500Kb", Q_NULLPTR)
         << QApplication::translate("hardwareinterface", "1000Kb", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class hardwareinterface: public Ui_hardwareinterface {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HARDWAREINTERFACE_H

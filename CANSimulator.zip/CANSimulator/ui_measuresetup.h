/********************************************************************************
** Form generated from reading UI file 'measuresetup.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEASURESETUP_H
#define UI_MEASURESETUP_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MeasureSetup
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MeasureSetup)
    {
        if (MeasureSetup->objectName().isEmpty())
            MeasureSetup->setObjectName(QStringLiteral("MeasureSetup"));
        MeasureSetup->resize(1113, 630);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/connection.png"), QSize(), QIcon::Normal, QIcon::Off);
        MeasureSetup->setWindowIcon(icon);
        centralwidget = new QWidget(MeasureSetup);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        MeasureSetup->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MeasureSetup);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1113, 21));
        MeasureSetup->setMenuBar(menubar);
        statusbar = new QStatusBar(MeasureSetup);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MeasureSetup->setStatusBar(statusbar);

        retranslateUi(MeasureSetup);

        QMetaObject::connectSlotsByName(MeasureSetup);
    } // setupUi

    void retranslateUi(QMainWindow *MeasureSetup)
    {
        MeasureSetup->setWindowTitle(QApplication::translate("MeasureSetup", "Measurement Setup", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MeasureSetup: public Ui_MeasureSetup {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEASURESETUP_H

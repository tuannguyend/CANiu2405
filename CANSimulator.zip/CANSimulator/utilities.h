#ifndef UTILITIES_H
#define UTILITIES_H
#include "CANDefines.h"
#include <QStringList>
#include <QAbstractSpinBox>
#include <QLineEdit>
#include <algorithm>
#include <limits>
#include <QDebug>
#define PI 3.1415926535898

typedef enum{
    E_Direction_Tx=0,
    E_Direction_Rx,
}E_Direction;

typedef enum{
    E_EventType_None=0,
    E_EventType_RTR,
    E_EventType_Error,
}E_EventType;

typedef struct CANSignalWaveData{
    struct __sine{
        unsigned int m_Cycle;
        double m_Amplitude;
        double m_Offset;
        int m_Phase;
    }m_Sine;
    struct __square{
        unsigned int m_CycleH;
        double m_PeakH;
        unsigned int m_CycleL;
        double m_PeakL;
    }m_Square;
    CANSignalWaveData(){
        m_Sine.m_Cycle = 1000;
        m_Sine.m_Amplitude = 10;
        m_Sine.m_Offset = 0;
        m_Sine.m_Phase = 0;
        m_Square.m_PeakH = 1;
        m_Square.m_PeakL = 0;
        m_Square.m_CycleH = 10;
        m_Square.m_CycleL = 10;
    }
}CANSignalWaveData;

class CANSignalSimulate{
public:
    CANSignalSimulate();
    ~CANSignalSimulate(){}
    unsigned char m_StartBit;
    CANSignal m_CANSign;
    bool m_WaveUsed;
    E_CANSignalWaveForm m_WaveForm;
    CANSignalWaveData m_WaveFormProperties;
    U_CANValue m_Value;
    U_CANValue m_ValueRun;
    U_CANValue to_signal_value(unsigned long long timestamp);
    U_CANValue to_signal_value(double phy_value);
    double to_physical_value(unsigned long long value);
    static void pack_intel(unsigned char * data, unsigned char startbit, unsigned char bitcount, unsigned long long value);
    static void pack_motorola(unsigned char * data, unsigned char startbit, unsigned char bitcount, unsigned long long value);
    static unsigned long long unpack_intel(unsigned char  const * data, bool sign,unsigned char startbit, unsigned char bitcount );
    static unsigned long long unpack_motorola(unsigned char  const * data, bool sign,unsigned char startbit, unsigned char bitcount );
    void pack(unsigned char * data,unsigned char length, unsigned long long timestamp); /*For transmit*/
    void unpack(unsigned char * data,unsigned char length); /*For transmit and receive*/
};

class CANMessageSimulate{
public:
    void pack(unsigned long long timestamp);
    void packall();
    void unpack();
    CANMessageSimulate(){
        m_CANSignals.clear();
        m_Direction = E_Direction_Rx;
        m_isReqToTx = false;
        m_Channel = 1;
        m_Cycle = 0;
        m_Id = 0;
        m_Len = 8;
        m_LenRun = 8;
        m_isCANErrorFrame=false;
        m_CycleSent = false;
        for (int i=0;i<8;i++) {
            m_Data[i]=0;
            m_DataRun[i]=0;
        }
    }
    ~CANMessageSimulate(){}
    QVector<CANSignalSimulate> m_CANSignals;
    bool m_isCANErrorFrame;
    QString m_DbPath;
    QString m_Name;
    E_Direction m_Direction;
    bool m_isReqToTx; //true RTR
    unsigned int m_Cycle;
    bool m_CycleSent;
    //    E_EventType m_Event;
    unsigned int m_Channel; //0: CAN, 1: CAN1, 2: CAN2
    unsigned int m_Id;
    unsigned char m_Len;
    unsigned char m_Data[8];
    unsigned char m_LenRun;
    unsigned char m_DataRun[8];
};

class CANSimulatorDatabaseAssosiate{
public:
    CANSimulatorDatabaseAssosiate(){}
    ~CANSimulatorDatabaseAssosiate(){}

    void addDbPath(const QString & path); // Add to path list and parse Db file
    void removeDbPath(const QString & path);
    inline const QStringList &getDbPath(){return m_Paths;}
    QVector<CANMessageSimulate> & getMessagesInfo(){return m_Messages;}
    const CANMessageSimulate & getMessagesInfo(const QString &path,const QString &msgName);

    CANMessageSimulate  getMessageById(unsigned int id, unsigned char len);

    QVector<CANMessageSimulate> & getMessagesByFile(QString &path);
    void test();

public slots:

private:
    QStringList m_Paths;
    QVector<CANMessageSimulate> m_Messages;
};

class  ULongLongSpinBox : public QAbstractSpinBox
{
    Q_OBJECT

public:
    ULongLongSpinBox(QWidget * parent = 0);

    virtual void fixup(QString & input) const;
    virtual void stepBy(int steps);
    virtual QValidator::State validate(QString & input, int & pos) const;

    qulonglong value() const;
    void setValue(qulonglong value);

    qulonglong minimum() const;
    void setMinimum(qulonglong minimum);

    qulonglong maximum() const;
    void setMaximum(qulonglong maximum);

    qulonglong step() const;
    void setStep(qulonglong step);

    void setRange(qulonglong min,
                  qulonglong max);
    void setBase(int base = 10);
signals:
    void valueChanged(qulonglong value);

protected slots:
    void onEditingFinished();

protected:
    virtual StepEnabled stepEnabled() const;

private:
    QString textFromValue(qulonglong value);
    qulonglong valueFromText(const QString & text);
    qulonglong validateAndInterpret(const QString & input,
                                    int & pos,
                                    QValidator::State & state) const;

private:
    qulonglong m_min;
    qulonglong m_max;
    qulonglong m_step;
    qulonglong m_value;
    int m_base;
};

class HexStringValidator : public QIntValidator {
public:
    HexStringValidator(QObject * parent) : QIntValidator(parent) {}

public:
    virtual void fixup(QString &input) const {
        input = input.toUpper();
    }

    virtual State validate(QString &input, int &pos) const {
        if(!input.isEmpty()) {
            bool ok;
            int number = input.toInt(&ok,16);
            if(ok){
                if(number < bottom() || number > top()){
                    return QValidator::Invalid;
                }else{
                    input = QString::number(number,16).toUpper();
                    return QValidator::Acceptable;
                }
            }else{
                return QValidator::Invalid;
            }
        }else{
            return QValidator::Acceptable;
        }
    }
};

class LineEdit: public QLineEdit
{
    Q_OBJECT
public:
    LineEdit(QWidget * parent=NULL):
        QLineEdit(parent)
        {}
    ~LineEdit(){}
protected:
    void mousePressEvent(QMouseEvent * evt)
    {
        emit textChanged(text());
    }

};
#endif // UTILITIES_H

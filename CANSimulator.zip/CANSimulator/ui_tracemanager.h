/********************************************************************************
** Form generated from reading UI file 'tracemanager.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRACEMANAGER_H
#define UI_TRACEMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TraceManager
{
public:
    QAction *m_ActionToggleTimeMode;
    QAction *m_ActionPausePlay;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QTreeView *m_treeView;
    QStatusBar *statusbar;
    QToolBar *m_toolBar;

    void setupUi(QMainWindow *TraceManager)
    {
        if (TraceManager->objectName().isEmpty())
            TraceManager->setObjectName(QStringLiteral("TraceManager"));
        TraceManager->resize(800, 600);
        m_ActionToggleTimeMode = new QAction(TraceManager);
        m_ActionToggleTimeMode->setObjectName(QStringLiteral("m_ActionToggleTimeMode"));
        m_ActionToggleTimeMode->setCheckable(true);
        m_ActionToggleTimeMode->setChecked(false);
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/timemode.PNG"), QSize(), QIcon::Normal, QIcon::Off);
        m_ActionToggleTimeMode->setIcon(icon);
        m_ActionPausePlay = new QAction(TraceManager);
        m_ActionPausePlay->setObjectName(QStringLiteral("m_ActionPausePlay"));
        m_ActionPausePlay->setCheckable(true);
        m_ActionPausePlay->setChecked(false);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/play.png"), QSize(), QIcon::Normal, QIcon::Off);
        icon1.addFile(QStringLiteral(":/icons/pause.png"), QSize(), QIcon::Normal, QIcon::On);
        m_ActionPausePlay->setIcon(icon1);
        centralwidget = new QWidget(TraceManager);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        m_treeView = new QTreeView(centralwidget);
        m_treeView->setObjectName(QStringLiteral("m_treeView"));

        gridLayout->addWidget(m_treeView, 0, 0, 1, 1);

        TraceManager->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(TraceManager);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        TraceManager->setStatusBar(statusbar);
        m_toolBar = new QToolBar(TraceManager);
        m_toolBar->setObjectName(QStringLiteral("m_toolBar"));
        TraceManager->addToolBar(Qt::TopToolBarArea, m_toolBar);

        m_toolBar->addAction(m_ActionToggleTimeMode);
        m_toolBar->addSeparator();
        m_toolBar->addAction(m_ActionPausePlay);

        retranslateUi(TraceManager);

        QMetaObject::connectSlotsByName(TraceManager);
    } // setupUi

    void retranslateUi(QMainWindow *TraceManager)
    {
        TraceManager->setWindowTitle(QApplication::translate("TraceManager", "MainWindow", Q_NULLPTR));
        m_ActionToggleTimeMode->setText(QString());
#ifndef QT_NO_TOOLTIP
        m_ActionToggleTimeMode->setToolTip(QApplication::translate("TraceManager", "Toggle time mode", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        m_ActionPausePlay->setText(QString());
#ifndef QT_NO_TOOLTIP
        m_ActionPausePlay->setToolTip(QApplication::translate("TraceManager", "Pause/Play trace view", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        m_toolBar->setWindowTitle(QApplication::translate("TraceManager", "toolBar", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TraceManager: public Ui_TraceManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRACEMANAGER_H

/****************************************************************************
** Meta object code from reading C++ file 'interactivemanager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../interactivemanager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'interactivemanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_InteractiveManagerWindow_t {
    QByteArrayData data[15];
    char stringdata0[210];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InteractiveManagerWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InteractiveManagerWindow_t qt_meta_stringdata_InteractiveManagerWindow = {
    {
QT_MOC_LITERAL(0, 0, 24), // "InteractiveManagerWindow"
QT_MOC_LITERAL(1, 25, 14), // "slotAddMessage"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 17), // "slotRemoveMessage"
QT_MOC_LITERAL(4, 59, 16), // "slotSpecialFrame"
QT_MOC_LITERAL(5, 76, 14), // "slotCellChange"
QT_MOC_LITERAL(6, 91, 3), // "row"
QT_MOC_LITERAL(7, 95, 6), // "column"
QT_MOC_LITERAL(8, 102, 16), // "slotWidgetChange"
QT_MOC_LITERAL(9, 119, 5), // "value"
QT_MOC_LITERAL(10, 125, 11), // "slotSendNow"
QT_MOC_LITERAL(11, 137, 16), // "slotMsgCellClick"
QT_MOC_LITERAL(12, 154, 19), // "slotSgnWidgetChange"
QT_MOC_LITERAL(13, 174, 17), // "slotSgnCellChange"
QT_MOC_LITERAL(14, 192, 17) // "slotSgnDefineWave"

    },
    "InteractiveManagerWindow\0slotAddMessage\0"
    "\0slotRemoveMessage\0slotSpecialFrame\0"
    "slotCellChange\0row\0column\0slotWidgetChange\0"
    "value\0slotSendNow\0slotMsgCellClick\0"
    "slotSgnWidgetChange\0slotSgnCellChange\0"
    "slotSgnDefineWave"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InteractiveManagerWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x0a /* Public */,
       3,    0,   75,    2, 0x0a /* Public */,
       4,    0,   76,    2, 0x0a /* Public */,
       5,    2,   77,    2, 0x0a /* Public */,
       8,    1,   82,    2, 0x0a /* Public */,
       8,    1,   85,    2, 0x0a /* Public */,
      10,    0,   88,    2, 0x0a /* Public */,
      11,    2,   89,    2, 0x0a /* Public */,
      12,    1,   94,    2, 0x0a /* Public */,
      12,    1,   97,    2, 0x0a /* Public */,
      13,    2,  100,    2, 0x0a /* Public */,
      14,    0,  105,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    6,    7,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    6,    7,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::ULongLong,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    6,    7,
    QMetaType::Void,

       0        // eod
};

void InteractiveManagerWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        InteractiveManagerWindow *_t = static_cast<InteractiveManagerWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slotAddMessage(); break;
        case 1: _t->slotRemoveMessage(); break;
        case 2: _t->slotSpecialFrame(); break;
        case 3: _t->slotCellChange((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->slotWidgetChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->slotWidgetChange((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->slotSendNow(); break;
        case 7: _t->slotMsgCellClick((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 8: _t->slotSgnWidgetChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->slotSgnWidgetChange((*reinterpret_cast< qulonglong(*)>(_a[1]))); break;
        case 10: _t->slotSgnCellChange((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 11: _t->slotSgnDefineWave(); break;
        default: ;
        }
    }
}

const QMetaObject InteractiveManagerWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_InteractiveManagerWindow.data,
      qt_meta_data_InteractiveManagerWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *InteractiveManagerWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InteractiveManagerWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_InteractiveManagerWindow.stringdata0))
        return static_cast<void*>(const_cast< InteractiveManagerWindow*>(this));
    if (!strcmp(_clname, "Ui_InteractiveManager"))
        return static_cast< Ui_InteractiveManager*>(const_cast< InteractiveManagerWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int InteractiveManagerWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}
struct qt_meta_stringdata_InteractiveManager_t {
    QByteArrayData data[1];
    char stringdata0[19];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InteractiveManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InteractiveManager_t qt_meta_stringdata_InteractiveManager = {
    {
QT_MOC_LITERAL(0, 0, 18) // "InteractiveManager"

    },
    "InteractiveManager"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InteractiveManager[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void InteractiveManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject InteractiveManager::staticMetaObject = {
    { &MeasureSetupManagerCommon::staticMetaObject, qt_meta_stringdata_InteractiveManager.data,
      qt_meta_data_InteractiveManager,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *InteractiveManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InteractiveManager::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_InteractiveManager.stringdata0))
        return static_cast<void*>(const_cast< InteractiveManager*>(this));
    return MeasureSetupManagerCommon::qt_metacast(_clname);
}

int InteractiveManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = MeasureSetupManagerCommon::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_InteractiveSignalDefineDialog_t {
    QByteArrayData data[5];
    char stringdata0[68];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InteractiveSignalDefineDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InteractiveSignalDefineDialog_t qt_meta_stringdata_InteractiveSignalDefineDialog = {
    {
QT_MOC_LITERAL(0, 0, 29), // "InteractiveSignalDefineDialog"
QT_MOC_LITERAL(1, 30, 11), // "slotEditted"
QT_MOC_LITERAL(2, 42, 0), // ""
QT_MOC_LITERAL(3, 43, 18), // "slotChangeWaveform"
QT_MOC_LITERAL(4, 62, 5) // "index"

    },
    "InteractiveSignalDefineDialog\0slotEditted\0"
    "\0slotChangeWaveform\0index"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InteractiveSignalDefineDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   24,    2, 0x0a /* Public */,
       3,    1,   25,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,

       0        // eod
};

void InteractiveSignalDefineDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        InteractiveSignalDefineDialog *_t = static_cast<InteractiveSignalDefineDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slotEditted(); break;
        case 1: _t->slotChangeWaveform((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject InteractiveSignalDefineDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_InteractiveSignalDefineDialog.data,
      qt_meta_data_InteractiveSignalDefineDialog,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *InteractiveSignalDefineDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InteractiveSignalDefineDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_InteractiveSignalDefineDialog.stringdata0))
        return static_cast<void*>(const_cast< InteractiveSignalDefineDialog*>(this));
    if (!strcmp(_clname, "Ui_InteractiveSignDefineDialog"))
        return static_cast< Ui_InteractiveSignDefineDialog*>(const_cast< InteractiveSignalDefineDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int InteractiveSignalDefineDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
struct qt_meta_stringdata_IGInsertMessageDialog_t {
    QByteArrayData data[3];
    char stringdata0[30];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_IGInsertMessageDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_IGInsertMessageDialog_t qt_meta_stringdata_IGInsertMessageDialog = {
    {
QT_MOC_LITERAL(0, 0, 21), // "IGInsertMessageDialog"
QT_MOC_LITERAL(1, 22, 6), // "accept"
QT_MOC_LITERAL(2, 29, 0) // ""

    },
    "IGInsertMessageDialog\0accept\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_IGInsertMessageDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void IGInsertMessageDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        IGInsertMessageDialog *_t = static_cast<IGInsertMessageDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->accept(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject IGInsertMessageDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_IGInsertMessageDialog.data,
      qt_meta_data_IGInsertMessageDialog,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *IGInsertMessageDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *IGInsertMessageDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_IGInsertMessageDialog.stringdata0))
        return static_cast<void*>(const_cast< IGInsertMessageDialog*>(this));
    if (!strcmp(_clname, "Ui_InsertMessageDialog"))
        return static_cast< Ui_InsertMessageDialog*>(const_cast< IGInsertMessageDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int IGInsertMessageDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE

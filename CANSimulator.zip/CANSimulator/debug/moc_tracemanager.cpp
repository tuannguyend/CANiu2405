/****************************************************************************
** Meta object code from reading C++ file 'tracemanager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../tracemanager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tracemanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TraceDataModel_t {
    QByteArrayData data[1];
    char stringdata0[15];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TraceDataModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TraceDataModel_t qt_meta_stringdata_TraceDataModel = {
    {
QT_MOC_LITERAL(0, 0, 14) // "TraceDataModel"

    },
    "TraceDataModel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TraceDataModel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void TraceDataModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject TraceDataModel::staticMetaObject = {
    { &MeasureSetupCommonModel::staticMetaObject, qt_meta_stringdata_TraceDataModel.data,
      qt_meta_data_TraceDataModel,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *TraceDataModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TraceDataModel::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_TraceDataModel.stringdata0))
        return static_cast<void*>(const_cast< TraceDataModel*>(this));
    return MeasureSetupCommonModel::qt_metacast(_clname);
}

int TraceDataModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = MeasureSetupCommonModel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_TraceWindow_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TraceWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TraceWindow_t qt_meta_stringdata_TraceWindow = {
    {
QT_MOC_LITERAL(0, 0, 11) // "TraceWindow"

    },
    "TraceWindow"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TraceWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void TraceWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject TraceWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_TraceWindow.data,
      qt_meta_data_TraceWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *TraceWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TraceWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_TraceWindow.stringdata0))
        return static_cast<void*>(const_cast< TraceWindow*>(this));
    if (!strcmp(_clname, "Ui_TraceManager"))
        return static_cast< Ui_TraceManager*>(const_cast< TraceWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int TraceWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_TraceManager_t {
    QByteArrayData data[4];
    char stringdata0[48];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TraceManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TraceManager_t qt_meta_stringdata_TraceManager = {
    {
QT_MOC_LITERAL(0, 0, 12), // "TraceManager"
QT_MOC_LITERAL(1, 13, 17), // "toggleTimeDisplay"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 15) // "togglePlayPause"

    },
    "TraceManager\0toggleTimeDisplay\0\0"
    "togglePlayPause"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TraceManager[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   24,    2, 0x0a /* Public */,
       3,    0,   25,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void TraceManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TraceManager *_t = static_cast<TraceManager *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->toggleTimeDisplay(); break;
        case 1: _t->togglePlayPause(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject TraceManager::staticMetaObject = {
    { &MeasureSetupManagerCommon::staticMetaObject, qt_meta_stringdata_TraceManager.data,
      qt_meta_data_TraceManager,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *TraceManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TraceManager::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_TraceManager.stringdata0))
        return static_cast<void*>(const_cast< TraceManager*>(this));
    return MeasureSetupManagerCommon::qt_metacast(_clname);
}

int TraceManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = MeasureSetupManagerCommon::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE

/****************************************************************************
** Meta object code from reading C++ file 'filtermanager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../filtermanager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'filtermanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_FilterManagerWindow_t {
    QByteArrayData data[13];
    char stringdata0[195];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FilterManagerWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FilterManagerWindow_t qt_meta_stringdata_FilterManagerWindow = {
    {
QT_MOC_LITERAL(0, 0, 19), // "FilterManagerWindow"
QT_MOC_LITERAL(1, 20, 16), // "signalSaveFilter"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 10), // "stopFilter"
QT_MOC_LITERAL(4, 49, 20), // "QVector<FilterData>&"
QT_MOC_LITERAL(5, 70, 9), // "addFilter"
QT_MOC_LITERAL(6, 80, 11), // "FilterData&"
QT_MOC_LITERAL(7, 92, 9), // "newFilter"
QT_MOC_LITERAL(8, 102, 12), // "slotOKButton"
QT_MOC_LITERAL(9, 115, 16), // "slotCancelButton"
QT_MOC_LITERAL(10, 132, 21), // "slotInsertRangeButton"
QT_MOC_LITERAL(11, 154, 23), // "slotInsertMessageButton"
QT_MOC_LITERAL(12, 178, 16) // "slotRemoveButton"

    },
    "FilterManagerWindow\0signalSaveFilter\0"
    "\0stopFilter\0QVector<FilterData>&\0"
    "addFilter\0FilterData&\0newFilter\0"
    "slotOKButton\0slotCancelButton\0"
    "slotInsertRangeButton\0slotInsertMessageButton\0"
    "slotRemoveButton"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FilterManagerWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   49,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   54,    2, 0x0a /* Public */,
       8,    0,   57,    2, 0x0a /* Public */,
       9,    0,   58,    2, 0x0a /* Public */,
      10,    0,   59,    2, 0x0a /* Public */,
      11,    0,   60,    2, 0x0a /* Public */,
      12,    0,   61,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 4,    3,    2,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void FilterManagerWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        FilterManagerWindow *_t = static_cast<FilterManagerWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signalSaveFilter((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< QVector<FilterData>(*)>(_a[2]))); break;
        case 1: _t->addFilter((*reinterpret_cast< FilterData(*)>(_a[1]))); break;
        case 2: _t->slotOKButton(); break;
        case 3: _t->slotCancelButton(); break;
        case 4: _t->slotInsertRangeButton(); break;
        case 5: _t->slotInsertMessageButton(); break;
        case 6: _t->slotRemoveButton(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (FilterManagerWindow::*_t)(bool , QVector<FilterData> & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FilterManagerWindow::signalSaveFilter)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject FilterManagerWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_FilterManagerWindow.data,
      qt_meta_data_FilterManagerWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *FilterManagerWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FilterManagerWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_FilterManagerWindow.stringdata0))
        return static_cast<void*>(const_cast< FilterManagerWindow*>(this));
    if (!strcmp(_clname, "Ui_FilterManager"))
        return static_cast< Ui_FilterManager*>(const_cast< FilterManagerWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int FilterManagerWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void FilterManagerWindow::signalSaveFilter(bool _t1, QVector<FilterData> & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
struct qt_meta_stringdata_FilterNodeManager_t {
    QByteArrayData data[6];
    char stringdata0[78];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FilterNodeManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FilterNodeManager_t qt_meta_stringdata_FilterNodeManager = {
    {
QT_MOC_LITERAL(0, 0, 17), // "FilterNodeManager"
QT_MOC_LITERAL(1, 18, 18), // "slotSaveFilterData"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 10), // "stopFilter"
QT_MOC_LITERAL(4, 49, 20), // "QVector<FilterData>&"
QT_MOC_LITERAL(5, 70, 7) // "filters"

    },
    "FilterNodeManager\0slotSaveFilterData\0"
    "\0stopFilter\0QVector<FilterData>&\0"
    "filters"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FilterNodeManager[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 4,    3,    5,

       0        // eod
};

void FilterNodeManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        FilterNodeManager *_t = static_cast<FilterNodeManager *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slotSaveFilterData((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< QVector<FilterData>(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObject FilterNodeManager::staticMetaObject = {
    { &MeasureSetupManagerCommon::staticMetaObject, qt_meta_stringdata_FilterNodeManager.data,
      qt_meta_data_FilterNodeManager,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *FilterNodeManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FilterNodeManager::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_FilterNodeManager.stringdata0))
        return static_cast<void*>(const_cast< FilterNodeManager*>(this));
    return MeasureSetupManagerCommon::qt_metacast(_clname);
}

int FilterNodeManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = MeasureSetupManagerCommon::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_FilterInsertDialog_t {
    QByteArrayData data[3];
    char stringdata0[27];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FilterInsertDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FilterInsertDialog_t qt_meta_stringdata_FilterInsertDialog = {
    {
QT_MOC_LITERAL(0, 0, 18), // "FilterInsertDialog"
QT_MOC_LITERAL(1, 19, 6), // "accept"
QT_MOC_LITERAL(2, 26, 0) // ""

    },
    "FilterInsertDialog\0accept\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FilterInsertDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void FilterInsertDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        FilterInsertDialog *_t = static_cast<FilterInsertDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->accept(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject FilterInsertDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_FilterInsertDialog.data,
      qt_meta_data_FilterInsertDialog,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *FilterInsertDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FilterInsertDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_FilterInsertDialog.stringdata0))
        return static_cast<void*>(const_cast< FilterInsertDialog*>(this));
    if (!strcmp(_clname, "Ui_FilterInserDialog"))
        return static_cast< Ui_FilterInserDialog*>(const_cast< FilterInsertDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int FilterInsertDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_FilterInsertMessageDialog_t {
    QByteArrayData data[7];
    char stringdata0[87];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FilterInsertMessageDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FilterInsertMessageDialog_t qt_meta_stringdata_FilterInsertMessageDialog = {
    {
QT_MOC_LITERAL(0, 0, 25), // "FilterInsertMessageDialog"
QT_MOC_LITERAL(1, 26, 16), // "signalAddNewItem"
QT_MOC_LITERAL(2, 43, 0), // ""
QT_MOC_LITERAL(3, 44, 11), // "FilterData&"
QT_MOC_LITERAL(4, 56, 6), // "filter"
QT_MOC_LITERAL(5, 63, 16), // "slotSearchButton"
QT_MOC_LITERAL(6, 80, 6) // "accept"

    },
    "FilterInsertMessageDialog\0signalAddNewItem\0"
    "\0FilterData&\0filter\0slotSearchButton\0"
    "accept"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FilterInsertMessageDialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   29,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,   32,    2, 0x0a /* Public */,
       6,    0,   33,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void FilterInsertMessageDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        FilterInsertMessageDialog *_t = static_cast<FilterInsertMessageDialog *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signalAddNewItem((*reinterpret_cast< FilterData(*)>(_a[1]))); break;
        case 1: _t->slotSearchButton(); break;
        case 2: _t->accept(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (FilterInsertMessageDialog::*_t)(FilterData & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&FilterInsertMessageDialog::signalAddNewItem)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject FilterInsertMessageDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_FilterInsertMessageDialog.data,
      qt_meta_data_FilterInsertMessageDialog,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *FilterInsertMessageDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FilterInsertMessageDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_FilterInsertMessageDialog.stringdata0))
        return static_cast<void*>(const_cast< FilterInsertMessageDialog*>(this));
    if (!strcmp(_clname, "Ui_InsertMessageDialog"))
        return static_cast< Ui_InsertMessageDialog*>(const_cast< FilterInsertMessageDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int FilterInsertMessageDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void FilterInsertMessageDialog::signalAddNewItem(FilterData & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE

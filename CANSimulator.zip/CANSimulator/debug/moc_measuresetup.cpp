/****************************************************************************
** Meta object code from reading C++ file 'measuresetup.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../measuresetup.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'measuresetup.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MeasureSetupWindow_t {
    QByteArrayData data[6];
    char stringdata0[76];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupWindow_t qt_meta_stringdata_MeasureSetupWindow = {
    {
QT_MOC_LITERAL(0, 0, 18), // "MeasureSetupWindow"
QT_MOC_LITERAL(1, 19, 19), // "slotDrawContextMenu"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 3), // "pos"
QT_MOC_LITERAL(4, 44, 17), // "slotOpenOpeWindow"
QT_MOC_LITERAL(5, 62, 13) // "slotTimerTest"

    },
    "MeasureSetupWindow\0slotDrawContextMenu\0"
    "\0pos\0slotOpenOpeWindow\0slotTimerTest"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   29,    2, 0x0a /* Public */,
       4,    0,   32,    2, 0x0a /* Public */,
       5,    0,   33,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QPoint,    3,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MeasureSetupWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MeasureSetupWindow *_t = static_cast<MeasureSetupWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slotDrawContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 1: _t->slotOpenOpeWindow(); break;
        case 2: _t->slotTimerTest(); break;
        default: ;
        }
    }
}

const QMetaObject MeasureSetupWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MeasureSetupWindow.data,
      qt_meta_data_MeasureSetupWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupWindow.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupWindow*>(this));
    if (!strcmp(_clname, "Ui_MeasureSetup"))
        return static_cast< Ui_MeasureSetup*>(const_cast< MeasureSetupWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MeasureSetupWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}
struct qt_meta_stringdata_MeasureSetupModel_t {
    QByteArrayData data[9];
    char stringdata0[110];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupModel_t qt_meta_stringdata_MeasureSetupModel = {
    {
QT_MOC_LITERAL(0, 0, 17), // "MeasureSetupModel"
QT_MOC_LITERAL(1, 18, 17), // "signalModelChange"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 18), // "slotAddDbAssosiate"
QT_MOC_LITERAL(4, 56, 6), // "dbPath"
QT_MOC_LITERAL(5, 63, 21), // "slotRemoveDbAssosiate"
QT_MOC_LITERAL(6, 85, 10), // "saveConfig"
QT_MOC_LITERAL(7, 96, 8), // "QString&"
QT_MOC_LITERAL(8, 105, 4) // "path"

    },
    "MeasureSetupModel\0signalModelChange\0"
    "\0slotAddDbAssosiate\0dbPath\0"
    "slotRemoveDbAssosiate\0saveConfig\0"
    "QString&\0path"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupModel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   34,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    1,   35,    2, 0x0a /* Public */,
       5,    1,   38,    2, 0x0a /* Public */,
       6,    1,   41,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, 0x80000000 | 7,    8,

       0        // eod
};

void MeasureSetupModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MeasureSetupModel *_t = static_cast<MeasureSetupModel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signalModelChange(); break;
        case 1: _t->slotAddDbAssosiate((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->slotRemoveDbAssosiate((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->saveConfig((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MeasureSetupModel::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MeasureSetupModel::signalModelChange)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject MeasureSetupModel::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_MeasureSetupModel.data,
      qt_meta_data_MeasureSetupModel,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupModel::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupModel.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupModel*>(this));
    return QObject::qt_metacast(_clname);
}

int MeasureSetupModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void MeasureSetupModel::signalModelChange()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}
struct qt_meta_stringdata_MeasureSetupWidget_t {
    QByteArrayData data[5];
    char stringdata0[60];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupWidget_t qt_meta_stringdata_MeasureSetupWidget = {
    {
QT_MOC_LITERAL(0, 0, 18), // "MeasureSetupWidget"
QT_MOC_LITERAL(1, 19, 17), // "signalContextMenu"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 3), // "pos"
QT_MOC_LITERAL(4, 42, 17) // "signalDoubleClick"

    },
    "MeasureSetupWidget\0signalContextMenu\0"
    "\0pos\0signalDoubleClick"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x06 /* Public */,
       4,    0,   27,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QPoint,    3,
    QMetaType::Void,

       0        // eod
};

void MeasureSetupWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MeasureSetupWidget *_t = static_cast<MeasureSetupWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signalContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 1: _t->signalDoubleClick(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MeasureSetupWidget::*_t)(const QPoint & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MeasureSetupWidget::signalContextMenu)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MeasureSetupWidget::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MeasureSetupWidget::signalDoubleClick)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject MeasureSetupWidget::staticMetaObject = {
    { &QToolButton::staticMetaObject, qt_meta_stringdata_MeasureSetupWidget.data,
      qt_meta_data_MeasureSetupWidget,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupWidget.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupWidget*>(this));
    return QToolButton::qt_metacast(_clname);
}

int MeasureSetupWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QToolButton::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void MeasureSetupWidget::signalContextMenu(const QPoint & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MeasureSetupWidget::signalDoubleClick()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}
struct qt_meta_stringdata_MeasureSetupManagerCommon_t {
    QByteArrayData data[5];
    char stringdata0[69];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupManagerCommon_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupManagerCommon_t qt_meta_stringdata_MeasureSetupManagerCommon = {
    {
QT_MOC_LITERAL(0, 0, 25), // "MeasureSetupManagerCommon"
QT_MOC_LITERAL(1, 26, 11), // "notifyEvent"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 25), // "MeasureSetupMessageCommon"
QT_MOC_LITERAL(4, 65, 3) // "msg"

    },
    "MeasureSetupManagerCommon\0notifyEvent\0"
    "\0MeasureSetupMessageCommon\0msg"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupManagerCommon[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   19,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

       0        // eod
};

void MeasureSetupManagerCommon::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MeasureSetupManagerCommon *_t = static_cast<MeasureSetupManagerCommon *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->notifyEvent((*reinterpret_cast< MeasureSetupMessageCommon(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MeasureSetupManagerCommon::*_t)(MeasureSetupMessageCommon );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MeasureSetupManagerCommon::notifyEvent)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject MeasureSetupManagerCommon::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_MeasureSetupManagerCommon.data,
      qt_meta_data_MeasureSetupManagerCommon,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupManagerCommon::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupManagerCommon::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupManagerCommon.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupManagerCommon*>(this));
    return QObject::qt_metacast(_clname);
}

int MeasureSetupManagerCommon::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void MeasureSetupManagerCommon::notifyEvent(MeasureSetupMessageCommon _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
struct qt_meta_stringdata_MeasureSetupItemCommon_t {
    QByteArrayData data[17];
    char stringdata0[243];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MeasureSetupItemCommon_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MeasureSetupItemCommon_t qt_meta_stringdata_MeasureSetupItemCommon = {
    {
QT_MOC_LITERAL(0, 0, 22), // "MeasureSetupItemCommon"
QT_MOC_LITERAL(1, 23, 21), // "signalDrawContextMenu"
QT_MOC_LITERAL(2, 45, 0), // ""
QT_MOC_LITERAL(3, 46, 3), // "pos"
QT_MOC_LITERAL(4, 50, 19), // "signalOpenOpeWindow"
QT_MOC_LITERAL(5, 70, 8), // "sendData"
QT_MOC_LITERAL(6, 79, 26), // "MeasureSetupMessageCommon&"
QT_MOC_LITERAL(7, 106, 4), // "data"
QT_MOC_LITERAL(8, 111, 7), // "rcvData"
QT_MOC_LITERAL(9, 119, 18), // "slotCloseOpeWindow"
QT_MOC_LITERAL(10, 138, 17), // "slotOpenOpeWindow"
QT_MOC_LITERAL(11, 156, 19), // "slotDrawContextMenu"
QT_MOC_LITERAL(12, 176, 15), // "slotEventNotify"
QT_MOC_LITERAL(13, 192, 25), // "MeasureSetupMessageCommon"
QT_MOC_LITERAL(14, 218, 3), // "evt"
QT_MOC_LITERAL(15, 222, 14), // "slotJoinToggle"
QT_MOC_LITERAL(16, 237, 5) // "check"

    },
    "MeasureSetupItemCommon\0signalDrawContextMenu\0"
    "\0pos\0signalOpenOpeWindow\0sendData\0"
    "MeasureSetupMessageCommon&\0data\0rcvData\0"
    "slotCloseOpeWindow\0slotOpenOpeWindow\0"
    "slotDrawContextMenu\0slotEventNotify\0"
    "MeasureSetupMessageCommon\0evt\0"
    "slotJoinToggle\0check"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MeasureSetupItemCommon[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       4,    0,   62,    2, 0x06 /* Public */,
       5,    1,   63,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    1,   66,    2, 0x0a /* Public */,
       9,    0,   69,    2, 0x0a /* Public */,
      10,    0,   70,    2, 0x0a /* Public */,
      11,    1,   71,    2, 0x0a /* Public */,
      12,    1,   74,    2, 0x0a /* Public */,
      15,    1,   77,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QPoint,    3,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,    3,
    QMetaType::Void, 0x80000000 | 13,   14,
    QMetaType::Void, QMetaType::Bool,   16,

       0        // eod
};

void MeasureSetupItemCommon::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MeasureSetupItemCommon *_t = static_cast<MeasureSetupItemCommon *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signalDrawContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 1: _t->signalOpenOpeWindow(); break;
        case 2: _t->sendData((*reinterpret_cast< MeasureSetupMessageCommon(*)>(_a[1]))); break;
        case 3: _t->rcvData((*reinterpret_cast< MeasureSetupMessageCommon(*)>(_a[1]))); break;
        case 4: _t->slotCloseOpeWindow(); break;
        case 5: _t->slotOpenOpeWindow(); break;
        case 6: _t->slotDrawContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 7: _t->slotEventNotify((*reinterpret_cast< MeasureSetupMessageCommon(*)>(_a[1]))); break;
        case 8: _t->slotJoinToggle((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (MeasureSetupItemCommon::*_t)(const QPoint & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MeasureSetupItemCommon::signalDrawContextMenu)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (MeasureSetupItemCommon::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MeasureSetupItemCommon::signalOpenOpeWindow)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (MeasureSetupItemCommon::*_t)(MeasureSetupMessageCommon & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&MeasureSetupItemCommon::sendData)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject MeasureSetupItemCommon::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_MeasureSetupItemCommon.data,
      qt_meta_data_MeasureSetupItemCommon,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MeasureSetupItemCommon::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MeasureSetupItemCommon::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MeasureSetupItemCommon.stringdata0))
        return static_cast<void*>(const_cast< MeasureSetupItemCommon*>(this));
    return QObject::qt_metacast(_clname);
}

int MeasureSetupItemCommon::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void MeasureSetupItemCommon::signalDrawContextMenu(const QPoint & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MeasureSetupItemCommon::signalOpenOpeWindow()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void MeasureSetupItemCommon::sendData(MeasureSetupMessageCommon & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE

/********************************************************************************
** Form generated from reading UI file 'interactivesignaldefinedialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INTERACTIVESIGNALDEFINEDIALOG_H
#define UI_INTERACTIVESIGNALDEFINEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_InteractiveSignDefineDialog
{
public:
    QGridLayout *gridLayout;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_6;
    QFormLayout *formLayout_3;
    QLabel *label_10;
    QLabel *m_SampleTimeWd;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *m_PhyMinWd;
    QLabel *m_PhyMaxWd;
    QLabel *m_RawMin;
    QLabel *m_RawMax;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_7;
    QCustomPlot *m_Plot;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_4;
    QTableWidget *m_TableValue;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_2;
    QStackedWidget *m_stackedWidget;
    QWidget *m_PageSine;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer_5;
    QFormLayout *formLayout;
    QLabel *label_2;
    QLineEdit *m_Amplitude;
    QLabel *label_3;
    QLineEdit *m_Period;
    QLabel *label_4;
    QLineEdit *m_Phase;
    QLabel *label_5;
    QLineEdit *m_Offset;
    QWidget *m_PageSquare;
    QGridLayout *gridLayout_5;
    QFormLayout *formLayout_2;
    QLabel *label_6;
    QLineEdit *m_CrestTime;
    QLineEdit *m_TroughTime;
    QLineEdit *m_CrestValue;
    QLineEdit *m_TroughValue;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QWidget *m_BlankPage;
    QSpacerItem *verticalSpacer_5;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QComboBox *m_SelectWaveForm;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *horizontalSpacer_3;
    QHBoxLayout *horizontalLayout_3;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *InteractiveSignDefineDialog)
    {
        if (InteractiveSignDefineDialog->objectName().isEmpty())
            InteractiveSignDefineDialog->setObjectName(QStringLiteral("InteractiveSignDefineDialog"));
        InteractiveSignDefineDialog->resize(550, 425);
        gridLayout = new QGridLayout(InteractiveSignDefineDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        groupBox_4 = new QGroupBox(InteractiveSignDefineDialog);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        gridLayout_6 = new QGridLayout(groupBox_4);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        formLayout_3 = new QFormLayout();
        formLayout_3->setObjectName(QStringLiteral("formLayout_3"));
        label_10 = new QLabel(groupBox_4);
        label_10->setObjectName(QStringLiteral("label_10"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_10);

        m_SampleTimeWd = new QLabel(groupBox_4);
        m_SampleTimeWd->setObjectName(QStringLiteral("m_SampleTimeWd"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, m_SampleTimeWd);

        label_11 = new QLabel(groupBox_4);
        label_11->setObjectName(QStringLiteral("label_11"));

        formLayout_3->setWidget(1, QFormLayout::LabelRole, label_11);

        label_12 = new QLabel(groupBox_4);
        label_12->setObjectName(QStringLiteral("label_12"));

        formLayout_3->setWidget(2, QFormLayout::LabelRole, label_12);

        label_13 = new QLabel(groupBox_4);
        label_13->setObjectName(QStringLiteral("label_13"));

        formLayout_3->setWidget(3, QFormLayout::LabelRole, label_13);

        label_14 = new QLabel(groupBox_4);
        label_14->setObjectName(QStringLiteral("label_14"));

        formLayout_3->setWidget(4, QFormLayout::LabelRole, label_14);

        m_PhyMinWd = new QLabel(groupBox_4);
        m_PhyMinWd->setObjectName(QStringLiteral("m_PhyMinWd"));

        formLayout_3->setWidget(1, QFormLayout::FieldRole, m_PhyMinWd);

        m_PhyMaxWd = new QLabel(groupBox_4);
        m_PhyMaxWd->setObjectName(QStringLiteral("m_PhyMaxWd"));

        formLayout_3->setWidget(2, QFormLayout::FieldRole, m_PhyMaxWd);

        m_RawMin = new QLabel(groupBox_4);
        m_RawMin->setObjectName(QStringLiteral("m_RawMin"));

        formLayout_3->setWidget(3, QFormLayout::FieldRole, m_RawMin);

        m_RawMax = new QLabel(groupBox_4);
        m_RawMax->setObjectName(QStringLiteral("m_RawMax"));

        formLayout_3->setWidget(4, QFormLayout::FieldRole, m_RawMax);


        gridLayout_6->addLayout(formLayout_3, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox_4, 3, 0, 1, 1);

        groupBox_3 = new QGroupBox(InteractiveSignDefineDialog);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout_7 = new QGridLayout(groupBox_3);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        m_Plot = new QCustomPlot(groupBox_3);
        m_Plot->setObjectName(QStringLiteral("m_Plot"));

        gridLayout_7->addWidget(m_Plot, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox_3, 4, 1, 1, 1);

        groupBox = new QGroupBox(InteractiveSignDefineDialog);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        gridLayout_4 = new QGridLayout(groupBox);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        m_TableValue = new QTableWidget(groupBox);
        if (m_TableValue->columnCount() < 2)
            m_TableValue->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        m_TableValue->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        m_TableValue->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        m_TableValue->setObjectName(QStringLiteral("m_TableValue"));

        gridLayout_4->addWidget(m_TableValue, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox, 4, 0, 1, 1);

        groupBox_2 = new QGroupBox(InteractiveSignDefineDialog);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayout_2 = new QGridLayout(groupBox_2);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        m_stackedWidget = new QStackedWidget(groupBox_2);
        m_stackedWidget->setObjectName(QStringLiteral("m_stackedWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_stackedWidget->sizePolicy().hasHeightForWidth());
        m_stackedWidget->setSizePolicy(sizePolicy);
        m_PageSine = new QWidget();
        m_PageSine->setObjectName(QStringLiteral("m_PageSine"));
        gridLayout_3 = new QGridLayout(m_PageSine);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_5, 0, 2, 1, 1);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        label_2 = new QLabel(m_PageSine);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_2);

        m_Amplitude = new QLineEdit(m_PageSine);
        m_Amplitude->setObjectName(QStringLiteral("m_Amplitude"));
        m_Amplitude->setInputMethodHints(Qt::ImhFormattedNumbersOnly);

        formLayout->setWidget(0, QFormLayout::FieldRole, m_Amplitude);

        label_3 = new QLabel(m_PageSine);
        label_3->setObjectName(QStringLiteral("label_3"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_3);

        m_Period = new QLineEdit(m_PageSine);
        m_Period->setObjectName(QStringLiteral("m_Period"));
        m_Period->setInputMethodHints(Qt::ImhDigitsOnly);

        formLayout->setWidget(1, QFormLayout::FieldRole, m_Period);

        label_4 = new QLabel(m_PageSine);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_4);

        m_Phase = new QLineEdit(m_PageSine);
        m_Phase->setObjectName(QStringLiteral("m_Phase"));
        m_Phase->setInputMethodHints(Qt::ImhDigitsOnly);

        formLayout->setWidget(2, QFormLayout::FieldRole, m_Phase);

        label_5 = new QLabel(m_PageSine);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(3, QFormLayout::LabelRole, label_5);

        m_Offset = new QLineEdit(m_PageSine);
        m_Offset->setObjectName(QStringLiteral("m_Offset"));
        m_Offset->setInputMethodHints(Qt::ImhDigitsOnly);

        formLayout->setWidget(3, QFormLayout::FieldRole, m_Offset);


        gridLayout_3->addLayout(formLayout, 0, 1, 1, 1);

        m_stackedWidget->addWidget(m_PageSine);
        m_PageSquare = new QWidget();
        m_PageSquare->setObjectName(QStringLiteral("m_PageSquare"));
        gridLayout_5 = new QGridLayout(m_PageSquare);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QStringLiteral("formLayout_2"));
        label_6 = new QLabel(m_PageSquare);
        label_6->setObjectName(QStringLiteral("label_6"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, label_6);

        m_CrestTime = new QLineEdit(m_PageSquare);
        m_CrestTime->setObjectName(QStringLiteral("m_CrestTime"));
        m_CrestTime->setInputMethodHints(Qt::ImhDigitsOnly);

        formLayout_2->setWidget(0, QFormLayout::FieldRole, m_CrestTime);

        m_TroughTime = new QLineEdit(m_PageSquare);
        m_TroughTime->setObjectName(QStringLiteral("m_TroughTime"));
        m_TroughTime->setInputMethodHints(Qt::ImhDigitsOnly);

        formLayout_2->setWidget(1, QFormLayout::FieldRole, m_TroughTime);

        m_CrestValue = new QLineEdit(m_PageSquare);
        m_CrestValue->setObjectName(QStringLiteral("m_CrestValue"));
        m_CrestValue->setInputMethodHints(Qt::ImhFormattedNumbersOnly);

        formLayout_2->setWidget(2, QFormLayout::FieldRole, m_CrestValue);

        m_TroughValue = new QLineEdit(m_PageSquare);
        m_TroughValue->setObjectName(QStringLiteral("m_TroughValue"));
        m_TroughValue->setInputMethodHints(Qt::ImhFormattedNumbersOnly);

        formLayout_2->setWidget(3, QFormLayout::FieldRole, m_TroughValue);

        label_7 = new QLabel(m_PageSquare);
        label_7->setObjectName(QStringLiteral("label_7"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, label_7);

        label_8 = new QLabel(m_PageSquare);
        label_8->setObjectName(QStringLiteral("label_8"));

        formLayout_2->setWidget(2, QFormLayout::LabelRole, label_8);

        label_9 = new QLabel(m_PageSquare);
        label_9->setObjectName(QStringLiteral("label_9"));

        formLayout_2->setWidget(3, QFormLayout::LabelRole, label_9);


        gridLayout_5->addLayout(formLayout_2, 0, 0, 1, 1);

        m_stackedWidget->addWidget(m_PageSquare);
        m_BlankPage = new QWidget();
        m_BlankPage->setObjectName(QStringLiteral("m_BlankPage"));
        m_stackedWidget->addWidget(m_BlankPage);

        gridLayout_2->addWidget(m_stackedWidget, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox_2, 3, 1, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_5, 0, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label = new QLabel(InteractiveSignDefineDialog);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_2->addWidget(label);

        m_SelectWaveForm = new QComboBox(InteractiveSignDefineDialog);
        m_SelectWaveForm->setObjectName(QStringLiteral("m_SelectWaveForm"));

        horizontalLayout_2->addWidget(m_SelectWaveForm);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);


        gridLayout->addLayout(horizontalLayout_2, 1, 0, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 1, 1, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        buttonBox = new QDialogButtonBox(InteractiveSignDefineDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        horizontalLayout_3->addWidget(buttonBox);


        gridLayout->addLayout(horizontalLayout_3, 5, 0, 1, 2);


        retranslateUi(InteractiveSignDefineDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), InteractiveSignDefineDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), InteractiveSignDefineDialog, SLOT(reject()));

        m_stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(InteractiveSignDefineDialog);
    } // setupUi

    void retranslateUi(QDialog *InteractiveSignDefineDialog)
    {
        InteractiveSignDefineDialog->setWindowTitle(QApplication::translate("InteractiveSignDefineDialog", "Set signal's waveform", Q_NULLPTR));
        groupBox_4->setTitle(QApplication::translate("InteractiveSignDefineDialog", "General information", Q_NULLPTR));
        label_10->setText(QApplication::translate("InteractiveSignDefineDialog", "Sample time [ms]:", Q_NULLPTR));
        m_SampleTimeWd->setText(QString());
        label_11->setText(QApplication::translate("InteractiveSignDefineDialog", "Physical min:", Q_NULLPTR));
        label_12->setText(QApplication::translate("InteractiveSignDefineDialog", "Physical max:", Q_NULLPTR));
        label_13->setText(QApplication::translate("InteractiveSignDefineDialog", "Raw min:", Q_NULLPTR));
        label_14->setText(QApplication::translate("InteractiveSignDefineDialog", "Raw max:", Q_NULLPTR));
        m_PhyMinWd->setText(QString());
        m_PhyMaxWd->setText(QString());
        m_RawMin->setText(QString());
        m_RawMax->setText(QString());
        groupBox_3->setTitle(QApplication::translate("InteractiveSignDefineDialog", "Graphical", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("InteractiveSignDefineDialog", "Values description", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = m_TableValue->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("InteractiveSignDefineDialog", "Value", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = m_TableValue->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("InteractiveSignDefineDialog", "Output", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("InteractiveSignDefineDialog", "Settings", Q_NULLPTR));
        label_2->setText(QApplication::translate("InteractiveSignDefineDialog", "Amplitude", Q_NULLPTR));
        label_3->setText(QApplication::translate("InteractiveSignDefineDialog", "Period [sample]", Q_NULLPTR));
        label_4->setText(QApplication::translate("InteractiveSignDefineDialog", "Phase [deg]", Q_NULLPTR));
        label_5->setText(QApplication::translate("InteractiveSignDefineDialog", "Offset", Q_NULLPTR));
        label_6->setText(QApplication::translate("InteractiveSignDefineDialog", "Crest [sample]", Q_NULLPTR));
        label_7->setText(QApplication::translate("InteractiveSignDefineDialog", "Trough [sample]", Q_NULLPTR));
        label_8->setText(QApplication::translate("InteractiveSignDefineDialog", "Crest value", Q_NULLPTR));
        label_9->setText(QApplication::translate("InteractiveSignDefineDialog", "Trough value", Q_NULLPTR));
        label->setText(QApplication::translate("InteractiveSignDefineDialog", "Select Wave form", Q_NULLPTR));
        m_SelectWaveForm->clear();
        m_SelectWaveForm->insertItems(0, QStringList()
         << QApplication::translate("InteractiveSignDefineDialog", "None", Q_NULLPTR)
         << QApplication::translate("InteractiveSignDefineDialog", "Sine", Q_NULLPTR)
         << QApplication::translate("InteractiveSignDefineDialog", "Square", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class InteractiveSignDefineDialog: public Ui_InteractiveSignDefineDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INTERACTIVESIGNALDEFINEDIALOG_H

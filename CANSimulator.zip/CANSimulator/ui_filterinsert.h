/********************************************************************************
** Form generated from reading UI file 'filterinsert.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FILTERINSERT_H
#define UI_FILTERINSERT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_FilterInserDialog
{
public:
    QGridLayout *gridLayout;
    QDialogButtonBox *buttonBox;
    QLineEdit *m_EndID;
    QLineEdit *m_StartID;
    QLabel *label_2;
    QLabel *label;
    QCheckBox *m_isExtended;

    void setupUi(QDialog *FilterInserDialog)
    {
        if (FilterInserDialog->objectName().isEmpty())
            FilterInserDialog->setObjectName(QStringLiteral("FilterInserDialog"));
        FilterInserDialog->resize(262, 119);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(FilterInserDialog->sizePolicy().hasHeightForWidth());
        FilterInserDialog->setSizePolicy(sizePolicy);
        gridLayout = new QGridLayout(FilterInserDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        buttonBox = new QDialogButtonBox(FilterInserDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 4, 1, 1, 1);

        m_EndID = new QLineEdit(FilterInserDialog);
        m_EndID->setObjectName(QStringLiteral("m_EndID"));

        gridLayout->addWidget(m_EndID, 2, 1, 1, 1);

        m_StartID = new QLineEdit(FilterInserDialog);
        m_StartID->setObjectName(QStringLiteral("m_StartID"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_StartID->sizePolicy().hasHeightForWidth());
        m_StartID->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(m_StartID, 0, 1, 1, 1);

        label_2 = new QLabel(FilterInserDialog);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        label = new QLabel(FilterInserDialog);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        m_isExtended = new QCheckBox(FilterInserDialog);
        m_isExtended->setObjectName(QStringLiteral("m_isExtended"));

        gridLayout->addWidget(m_isExtended, 3, 0, 1, 1);


        retranslateUi(FilterInserDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), FilterInserDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), FilterInserDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(FilterInserDialog);
    } // setupUi

    void retranslateUi(QDialog *FilterInserDialog)
    {
        FilterInserDialog->setWindowTitle(QApplication::translate("FilterInserDialog", "Insert filter", Q_NULLPTR));
        label_2->setText(QApplication::translate("FilterInserDialog", "End ID", Q_NULLPTR));
        label->setText(QApplication::translate("FilterInserDialog", "Start ID", Q_NULLPTR));
        m_isExtended->setText(QApplication::translate("FilterInserDialog", "Extended Id", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class FilterInserDialog: public Ui_FilterInserDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FILTERINSERT_H

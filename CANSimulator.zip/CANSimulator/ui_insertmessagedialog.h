/********************************************************************************
** Form generated from reading UI file 'insertmessagedialog.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INSERTMESSAGEDIALOG_H
#define UI_INSERTMESSAGEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTreeWidget>

QT_BEGIN_NAMESPACE

class Ui_InsertMessageDialog
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLineEdit *m_searchContent;
    QPushButton *m_searchButton;
    QDialogButtonBox *buttonBox;
    QTreeWidget *m_treeWidget;

    void setupUi(QDialog *InsertMessageDialog)
    {
        if (InsertMessageDialog->objectName().isEmpty())
            InsertMessageDialog->setObjectName(QStringLiteral("InsertMessageDialog"));
        InsertMessageDialog->resize(664, 471);
        gridLayout = new QGridLayout(InsertMessageDialog);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        m_searchContent = new QLineEdit(InsertMessageDialog);
        m_searchContent->setObjectName(QStringLiteral("m_searchContent"));

        horizontalLayout->addWidget(m_searchContent);

        m_searchButton = new QPushButton(InsertMessageDialog);
        m_searchButton->setObjectName(QStringLiteral("m_searchButton"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/icons/search.png"), QSize(), QIcon::Normal, QIcon::Off);
        m_searchButton->setIcon(icon);

        horizontalLayout->addWidget(m_searchButton);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        buttonBox = new QDialogButtonBox(InsertMessageDialog);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        gridLayout->addWidget(buttonBox, 2, 0, 1, 1);

        m_treeWidget = new QTreeWidget(InsertMessageDialog);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/icons/connection.png"), QSize(), QIcon::Normal, QIcon::Off);
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/icons/message.png"), QSize(), QIcon::Normal, QIcon::Off);
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/icons/error.png"), QSize(), QIcon::Normal, QIcon::Off);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem(m_treeWidget);
        __qtreewidgetitem->setIcon(0, icon1);
        QTreeWidgetItem *__qtreewidgetitem1 = new QTreeWidgetItem(__qtreewidgetitem);
        __qtreewidgetitem1->setIcon(0, icon1);
        QTreeWidgetItem *__qtreewidgetitem2 = new QTreeWidgetItem(__qtreewidgetitem1);
        __qtreewidgetitem2->setIcon(0, icon2);
        QTreeWidgetItem *__qtreewidgetitem3 = new QTreeWidgetItem(__qtreewidgetitem2);
        __qtreewidgetitem3->setIcon(0, icon3);
        m_treeWidget->setObjectName(QStringLiteral("m_treeWidget"));

        gridLayout->addWidget(m_treeWidget, 1, 0, 1, 1);


        retranslateUi(InsertMessageDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), InsertMessageDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), InsertMessageDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(InsertMessageDialog);
    } // setupUi

    void retranslateUi(QDialog *InsertMessageDialog)
    {
        InsertMessageDialog->setWindowTitle(QApplication::translate("InsertMessageDialog", "Dialog", Q_NULLPTR));
        m_searchButton->setText(QApplication::translate("InsertMessageDialog", "Search", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem = m_treeWidget->headerItem();
        ___qtreewidgetitem->setText(3, QApplication::translate("InsertMessageDialog", "Comment", Q_NULLPTR));
        ___qtreewidgetitem->setText(2, QApplication::translate("InsertMessageDialog", "Identifier", Q_NULLPTR));
        ___qtreewidgetitem->setText(1, QApplication::translate("InsertMessageDialog", "Tx Node", Q_NULLPTR));
        ___qtreewidgetitem->setText(0, QApplication::translate("InsertMessageDialog", "Name", Q_NULLPTR));

        const bool __sortingEnabled = m_treeWidget->isSortingEnabled();
        m_treeWidget->setSortingEnabled(false);
        QTreeWidgetItem *___qtreewidgetitem1 = m_treeWidget->topLevelItem(0);
        ___qtreewidgetitem1->setText(0, QApplication::translate("InsertMessageDialog", "Predefined events", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem2 = ___qtreewidgetitem1->child(0);
        ___qtreewidgetitem2->setText(0, QApplication::translate("InsertMessageDialog", "CAN", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem3 = ___qtreewidgetitem2->child(0);
        ___qtreewidgetitem3->setText(0, QApplication::translate("InsertMessageDialog", "Events", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem4 = ___qtreewidgetitem3->child(0);
        ___qtreewidgetitem4->setText(3, QApplication::translate("InsertMessageDialog", "CAN error frame", Q_NULLPTR));
        ___qtreewidgetitem4->setText(0, QApplication::translate("InsertMessageDialog", "Error frame", Q_NULLPTR));
        m_treeWidget->setSortingEnabled(__sortingEnabled);

    } // retranslateUi

};

namespace Ui {
    class InsertMessageDialog: public Ui_InsertMessageDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INSERTMESSAGEDIALOG_H
